var move1 = document.getElementById("myRange1");
var  output1 = document.getElementById("value1");

output1.innerHTML = move1.value;

move1.oninput = function() {
    output1.innerHTML = this.value;
    
}


var move2 = document.getElementById("myRange2");
var  output2 = document.getElementById("value2");

output2.innerHTML = move2.value;

move2.oninput = function() {
    output2.innerHTML = this.value;
    
}


var move3 = document.getElementById("myRange3");
var  output3 = document.getElementById("value3");

output3.innerHTML = move3.value;

move3.oninput = function() {
    output3.innerHTML = this.value;
    
}


var move4 = document.getElementById("myRange4");
var  output4 = document.getElementById("value4");

output4.innerHTML = move4.value;

move4.oninput = function() {
    output4.innerHTML = this.value;
    
}



var move5 = document.getElementById("myRange5");
var  output5 = document.getElementById("value5");

output5.innerHTML = move5.value;

move5.oninput = function() {
    output5.innerHTML = this.value;
    
}
    
var move6 = document.getElementById("myRange6");
var  output6 = document.getElementById("value6");

output6.innerHTML = move6.value;

move6.oninput = function() {
    output6.innerHTML = this.value;
    
}